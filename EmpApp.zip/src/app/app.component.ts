import { Component } from '@angular/core';
import { Emp } from './emp';
import { EmpService } from './emp.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  employees: Emp[]=[];
constructor(private empService:EmpService)
{}
ngOnInit():void{
  this.employees = this.empService.getEmployees();
}

calculateSalary(employee:Emp):number{
  return this.empService.calculateTotalSalary(employee);
}
}
