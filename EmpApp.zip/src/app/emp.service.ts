import { Injectable } from '@angular/core';
import { Emp } from './emp';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  private employees: Emp[] =[
    new Emp(1,"John","Dev",50000,5000),
    new Emp(2,"Devid","QA",60000,6000)
  ]

  getEmployees():Emp[]{
    return this.employees;
  }

  calculateTotalSalary(employee:Emp):number{
    return employee.getTotalSalary();
  }
  constructor() { }
}
