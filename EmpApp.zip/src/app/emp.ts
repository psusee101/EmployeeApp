export class Emp 
{
    id:number;
  name:string;
  department:string;
  salary:number;
  bonus:number;

  constructor(id:number,name:string,department:string,salary:number,bonus:number)
  {
    this.id = id;
    this.name = name;
    this.department = department;
    this.salary = salary;
    this.bonus = bonus;
  }

  getTotalSalary():number{
    return this.salary+this.bonus;
  }
}
